package com.example.wordlepal;

public class Message {
    
    private String msg;

    public void setMessage(String s) { this.msg = s; }

    public String getMessage() { return msg; }
}
