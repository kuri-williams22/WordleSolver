package com.example.wordlepal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordlePalApplication {

	public static void main(String[] args) {
		SpringApplication.run(WordlePalApplication.class, args);
	}

}
